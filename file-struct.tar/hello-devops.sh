echo "Hello chmyint!"




"\?$*'Hard_file'*$?\" which contains Random text inside! and nothing else.

